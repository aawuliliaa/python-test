create view myview as
select `db2`.`student1`.`ID`     AS `ID`,
       `db2`.`student1`.`sname`  AS `sname`,
       `db2`.`student1`.`gender` AS `gender`,
       `db2`.`student1`.`credit` AS `credit`,
       `db2`.`student1`.`height` AS `height`
from `db2`.`student1`;

