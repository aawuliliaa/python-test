create
    definer = root@`10.0.0.%` procedure p1()
BEGIN
select * from student1;
end;

